<?php // Conexión a la base de datos 

$mysqli = new mysqli("sql201.infinityfree.com", "if0_39822322", "kZCernMdrXz", "if0_39822322_inscriptos");
if ($mysqli->connect_errno) { // Error de conexión - redirigir con parámetro de error
    header("Location: https://inscripciones-utu-api.wuaze.com/index.html?error=conexion");
    exit();
}
if (!$mysqli->connect_errno) {
    $mysqli->set_charset('utf8mb4');
} // Verifica que se use POST para insertar datos
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: https://inscripciones-utu-api.wuaze.com/index.html?error=metodo");
    exit();
} // Sanitizar los datos de entrada 
$nombreCompleto = trim($_POST['Nombre_Completo']);
$edad = intval($_POST['Edad']);
$telefono = trim($_POST['Teléfono']);
$cedula = trim($_POST['Cédula']);
$genero = trim($_POST['Genero'] ?? '');
$distancia = trim($_POST['Distancia'] ?? '');
$nmro_corredor = trim($_POST['inputNumero'] ?? ''); // Verificar si el deslinde fue confirmado (checkbox marcado)
$deslindeConfirmado = isset($_POST['confirmacionDeslinde']) && $_POST['confirmacionDeslinde'] === 'on'; // Validar que se haya confirmado el deslinde 
if (!$deslindeConfirmado) {
    header("Location: https://inscripciones-utu-api.wuaze.com/index.html?error=deslinde");
    exit();
} // Validaciones adicionales
if ($edad <= 0 || $edad > 150) {
    header("Location: https://inscripciones-utu-api.wuaze.com/index.html?error=edad");
    exit();
} // Preparar la consulta INSERT con parámetros para prevenir inyección SQL
$sql = "INSERT INTO inscripto (nombre_completo, edad, telefono, cedula,genero, distancia,numero_corredor ) VALUES (?, ?, ?, ?, ?, ?, ?)";
$stmt = $mysqli->prepare($sql);
if (!$stmt) {
    header("Location: https://inscripciones-utu-api.wuaze.com/index.html?error=preparacion");
    exit();
} // Vincular parámetros (s = string, i = integer) // 7 parámetros: 6 strings y 1 integer (edad)
$stmt->bind_param("sisssss", $nombreCompleto, $edad, $telefono, $cedula, $genero, $distancia, $nmro_corredor); // Ejecutar la consulta
if ($stmt->execute()) { // Éxito al insertar - redirigir con éxito 
    header("Location: https://inscripciones-utu-api.wuaze.com/index.html?success=true");
    exit();
} else { // Error al insertar
    header("Location: https://inscripciones-utu-api.wuaze.com/index.html?error=insercion");
    exit();
} // Cerrar statement y conexión
$stmt->close();
$mysqli->close();
