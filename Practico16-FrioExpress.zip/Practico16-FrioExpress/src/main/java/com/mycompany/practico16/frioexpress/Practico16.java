/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.practico16.frioexpress;

import controlador.ProductoController;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import modelo.Producto;

/**
 *
 * @author maria
 */
public class Practico16 {

    static Scanner sc = new Scanner(System.in);
    private static ProductoController controladorProducto = new ProductoController();

    public static void main(String[] args) {

        System.out.println("INGRESE UNA OPCION");
        System.out.println("1. Ingresar producto");
        System.out.println("2. Ingresar cliente");
        System.out.println("3. Realizar pedido");
        System.out.println("4. Mostrar productos con stock minimo");
        System.out.println("5. Alerta de cadena de frio");
        System.out.println("6. Salir");
        System.out.print("Seleccione una opción: ");
        int opcion = sc.nextInt();

        switch (opcion) {
            case 1:
                ingresarProducto();
                break;
            case 2:
                break;

            case 3:
                break;

            case 4:

                break;
        }

    }

    public static void mostrarStockMinimo() {
        List<Producto> StockMinimos = new ArrayList<>();
        StockMinimos = controladorProducto.getProductosStockMinimo();
        for (Producto unProducto : StockMinimos) {
            System.out.println("Código: " + unProducto.getCodigo()
                    + ", Nombre: " + unProducto.getNombre()
                    + ", Temperatura: " + unProducto.getTemperatura()
                    + ", Minutos fuera: " + unProducto.getMinutos());
        }
    }

    public static void alertaCadenaFrio() {

    }

    public static void ingresarProducto() {
        System.out.println("Ingrese el codigo: ");
        int codigo = sc.nextInt();
        sc.nextLine(); // limpia el salto de línea pendiente
        System.out.println("Ingrese el nombre: ");
        String nombre = sc.nextLine();
        System.out.println("Ingrese la categoria: ");
        String categoria = sc.nextLine();
        //Cuando usas nextInt() o nextFloat(), el Scanner no consume el salto de línea, así que el siguiente nextLine() se salta la entrada.
        System.out.println("Ingrese la temperatura: ");
        int temperatura = sc.nextInt();
        sc.nextLine(); // limpia el salto de línea pendiente
        System.out.println("Ingrese el stock: ");
        int stock = sc.nextInt();
        sc.nextLine(); // limpia el salto de línea pendiente
        System.out.println("Ingrese el stock minimo: ");
        int stock_minimo = sc.nextInt();
        sc.nextLine(); // limpia el salto de línea pendiente
        int minutos = sc.nextInt();
        sc.nextLine();
        System.out.println("Ingrese el precio: ");
        float precio = sc.nextFloat();
        sc.nextLine(); // limpia el salto de línea pendiente
        Producto unProducto = new Producto(codigo, nombre, categoria, temperatura, stock, stock_minimo, precio, minutos);
        controladorProducto.agregarProducto(unProducto);

    }

}
